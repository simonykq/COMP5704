from __future__ import division  # for Python 2
from constants import T

from numba import cuda, float32
from math import pow, sqrt, ceil
from pyculib.sorting.radixsort import RadixSort

import numba as nb
import numpy as np

# The non-shared memory version
@cuda.jit
def euclidean_kernel(X, Y, Z):
    x, y = cuda.grid(2)
    if x < Y.shape[1] and y < X.shape[1]:
        tmp = 0.
        for i in range(X.shape[0]):
            tmp += pow(X[i, x] - Y[i, y], 2)
        Z[x, y] = sqrt(tmp)

# The shared memory version with coalesced memory access
@cuda.jit
def fast_euclidean_kernel(X, Y, Z):
    # Global position of thread(x, y)
    x, y = cuda.grid(2)

    # Check if it is out of bound
    if x >= Z.shape[0] and y >= Z.shape[1]:
        return

    # The shared memory that store the sub matrices to be shared within a thread block
    subX = cuda.shared.array(shape=(T, T), dtype=float32)
    subY = cuda.shared.array(shape=(T, T), dtype=float32)

    # Local position of thread(tx, ty) within the thread block
    tx = cuda.threadIdx.x
    ty = cuda.threadIdx.y

    # Dimension of the input vector X
    m = int(ceil(X.shape[0] / T))  # OR Y.shape[1] / BLOCK_SIZE

    zValue = 0.
    for i in range(m):
        subX[tx, ty] = 0.0
        subY[tx, ty] = 0.0
        # Bound check
        if ty + i * T < X.shape[0]:
            # Load the data from global memory into temporary memory
            subX[tx, ty] = X[ty + i * T, x]
        if tx + i * T < Y.shape[1]:
            subY[tx, ty] = Y[y, tx + i * T]

        # Wait until all threads within current thread block finish loading
        cuda.syncthreads()

        # Calculate the partial sum of Euclidean Distance
        for j in range(T):
            zValue += pow(subX[tx, j] - subY[j, ty], 2)

        # Wait for all threads to finish calculating partial sum
        cuda.syncthreads()

    Z[x, y] = sqrt(zValue)

# The shared memory version without coalesced memory access
@cuda.jit
def fast_euclidean_kernel_2(X, Y, Z):
    # Global position of thread(x, y)
    x, y = cuda.grid(2)

    # Check if it is out of bound
    if x >= Z.shape[0] and y >= Z.shape[1]:
        return

    # The shared memory that store the sub matrices to be shared within a thread block
    subX = cuda.shared.array(shape=(T, T), dtype=float32)
    subY = cuda.shared.array(shape=(T, T), dtype=float32)

    # Local position of thread(tx, ty) within the thread block
    tx = cuda.threadIdx.x
    ty = cuda.threadIdx.y

    # Dimension of the input vector X
    m = int(ceil(X.shape[0] / T))  # OR Y.shape[0] / BLOCK_SIZE

    zValue = 0.
    for i in range(m):
        subX[tx, ty] = 0.0
        subY[tx, ty] = 0.0
        # Bound check
        if ty + i * T < X.shape[0]:
            # Load the data from global memory into temporary memory
            subX[tx, ty] = X[ty + i * T, x]
        if tx + i * T < Y.shape[0]:
            subY[tx, ty] = Y[tx + i * T, y]
        # Wait until all threads within current thread block finish loading
        cuda.syncthreads()

        # Calculate the partial sum of Euclidean Distance
        for j in range(T):
            zValue += pow(subX[tx, j] - subY[j, ty], 2)

        # Wait for all threads to finish calculating partial sum
        cuda.syncthreads()

    Z[x, y] = sqrt(zValue)


# Find the k-distance of the C
def k_distance(Z, k):

    Z = np.array(Z, dtype=np.float32).T
    Z = np.ascontiguousarray(Z)
    for c in Z:
        # stream = nb.cuda.stream()
        # Use the RadixSort library from Pyculib to sort the distance
        radix_sort = RadixSort(c.size, c.dtype, False)
        radix_sort.sort(c)

    return Z[:,k-1]

# Find the k-nearest neighbourhood of the C
def k_nearest_neighbourhood(Z, k):

    index = 0
    Z = np.array(Z, dtype=np.float32).T
    Z = np.ascontiguousarray(Z)
    R = np.zeros((Z.shape[0], k), dtype=np.uint32)
    for c in Z:
        # stream = nb.cuda.stream()
        # Use the RadixSort library from Pyculib to sort
        radix_sort = RadixSort(c.size, c.dtype, False)
        R[index] = radix_sort.argselect(k, c)
        index += 1

    return R