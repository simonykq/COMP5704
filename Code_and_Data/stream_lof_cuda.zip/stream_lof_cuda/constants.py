# Size for the KNN
K_SIZE = 10
# Block Size to run in kernel for KNN
T = 32

# Divide each dimension into K slots
K = 2
# Data dimension
D = 64
# Number of data
N = 1024

SHARED_MEMORY = False