#!/usr/bin/env python2
from __future__ import division  # for Python 2

import numpy as np
import matplotlib.pyplot as plt

from timeit import default_timer as timer
from constants import *
from c_lof import C_LOF
from bin_summary import BINSummary
import cProfile as profile


np.random.seed(42)

# Generate train data
X = 0.3 * np.random.randn(int((N - 20) / 2), D)
# Generate some abnormal novel observations
X_outliers_1 = np.random.uniform(low=-10, high=-20, size=(10, D))
X_outliers_2 = np.random.uniform(low=10, high=20, size=(10, D))
X = np.r_[X + 2, X - 2, X_outliers_1, X_outliers_2]

def main():
    summary = BINSummary()
    lof_engine = C_LOF(summary, T, K_SIZE, SHARED_MEMORY, theta=0.1)

    start = timer()
    Y = lof_engine.fit_predict(X.T)
    total_time = timer() - start

    inliers = np.where(Y == 1)[0]
    outliers = np.where(Y == -1)[0]

    print("Results:")
    print("Inliers: {0}".format(inliers))
    print("Outliers: {0}".format(outliers))

    print("Performances:")
    print("Total time: %f seconds" % total_time)
    # plot the level sets of the decision function
    # xx, yy = np.meshgrid(np.linspace(-20, 20, 32), np.linspace(-20, 20, 32))
    # Z = lof_engine._score(np.c_[xx.ravel(), yy.ravel()].T, np.array([]), np.array([]))
    # Z = np.reciprocal(Z)
    # Z = Z.reshape(xx.shape)
    #
    # plt.title("Local Outlier Factor (LOF)")
    # plt.contourf(xx, yy, Z, cmap=plt.cm.Blues_r)

    # a = plt.scatter(X[inliers, 0], X[inliers, 1], c='white',
    #                 edgecolor='k', s=20)
    # b = plt.scatter(X[outliers, 0], X[outliers, 1], c='red',
    #                 edgecolor='k', s=20)
    # plt.axis('tight')
    # plt.xlim((-20, 20))
    # plt.ylim((-20, 20))
    # plt.legend([a, b],
    #            ["normal observations",
    #             "abnormal observations"],
    #            loc="upper left")
    # plt.show()

if __name__ == "__main__": main()

# profile.run("main()", sort='time')