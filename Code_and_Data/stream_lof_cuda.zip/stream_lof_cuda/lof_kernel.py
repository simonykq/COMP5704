from __future__ import division  # for Python 2
from constants import K_SIZE, D

from numba import cuda, float32
from math import pow, sqrt

# LRD is the total lrd values including the synthetic ones from bin
@cuda.jit
def lof_kernel(K_NN, LRD, LOF):
    i = cuda.blockIdx.x
    j = cuda.threadIdx.x

    # Bound check
    if i < K_NN.shape[0] and j < K_NN.shape[1]:
        # The shared memory that store the neighbors lrd values
        knn = cuda.shared.array(K_SIZE, dtype=float32)
        # The shared memory that store the current data point lrd at index i
        lrd = cuda.shared.array(1, dtype=float32)
        # The index of the neighborhood
        index = K_NN[i][j]
        # Store the neighbor's lrd value in shared memory
        knn[j] = LRD[index]
        # Store the lrd of current data point at shared memory
        lrd[0] = LRD[i]

        # Wait until all threads within current thread block finish loading
        cuda.syncthreads()

        # Definition of LOF, get the lof value of this data
        LOF[i] = (sum(knn) / K_SIZE) / lrd[0]

# T is total data point including BIN data, in dimension D * (N + B), K is (N + B) vector
# containing data points from both BIN and data points
# Block dimension is equal to the size of data input N, thread dimension is equal to K
@cuda.jit
def lrd_kernel(K_NN, T, K, LRD):
    i = cuda.blockIdx.x
    j = cuda.threadIdx.x

    # k = cuda.grid(1)

    # Bound check
    if i < K_NN.shape[0] and j < K_NN.shape[1]:

        # The shared memory that store the neighbors max(dist(p,q), k-dist(q))
        knn = cuda.shared.array(K_SIZE, dtype=float32)
        # The shared memory that store the centroid data point p at index i
        p = cuda.shared.array((1, D), dtype=float32)

        # The index of the neighborhood
        index = K_NN[i][j]
        # store the current centroid data point in shared memory
        for x in range(D):
            p[0][x] = T[x][i]
        # The correspond neighborhood data point of the index
        q = T[:, index]
        # The distance between p and q
        dist_p_q = dist(p[0], q)
        # The k-distance of data point of the index
        k_dist = K[index]
        # Store the maximum between dist(p,q) and k-dist(q) in shared memory
        knn[j] = max(dist_p_q, k_dist)

        # Wait until all threads within current thread block finish loading
        cuda.syncthreads()

        # Set the lrd result of ith data based on definition
        LRD[i] = 1 / (sum(knn) / K_SIZE)


@cuda.jit(device=True)
def dist(A, B):
    tmp = 0.
    for i in range(A.shape[0]):
        tmp += pow(A[i] - B[i], 2)
    return sqrt(tmp)

@cuda.jit(device=True)
def sum(A):
    tmp = 0.
    for i in range(A.shape[0]):
        tmp += A[i]
    return sqrt(tmp)