from __future__ import division  # for Python 2
from itertools import groupby

import numpy as np

# The bin summary maintain the mu and count of the data from previous window across all bins k^d
# mu is maintained across each dimension
class BINSummary:

    def __init__(self, K, D):
        self.bins = []
        self.K = K
        self.bound = np.full((D, 2), -1, dtype=np.float32)

    def calculate_bin_statistic(self, data_t):
        self.__update_bound(data_t)
        # merge the bin and new data points
        # for new data point, the bin index is initialized to -1 with count 1 and mean value to itself
        points = [(-1, 1, x) for x in data_t.T] + self.bins
        # Map
        mapped_points = map(self.map_stage, points)
        # Group
        grouped_by_points = [(k, list(p)) for k, p in groupby(mapped_points, lambda p: p[0])]
        # Reduce
        self.bins = map(self.reduce_stage, grouped_by_points)

    # Map the data. The input could be the new data point or the bin
    # Return a tuple of three elements. The first is the bin index,
    # second is count, third is mean value vector, or in case it is a new data, it is the data point itself
    def map_stage(self, point):
        # if this is a bin, return it it self
        if point[0] != -1:
            return point[0], point[1], point[2]
        # if this is a data point, calculate its index with count 1 and mean value to itself
        else:
            return self.__calculate_bin_index(point[2]), 1, point[2]

    # Reduce the data. The input is a tuple whose first element is the mapped index and second is the
    # list of return elements from map stage in that index
    # Return a tuple of three elements. The first is the bin index,
    # second is the aggregated count and the third is the aggregated mean value vector
    def reduce_stage(self, tup):
        points = tup[1]
        count = sum(map(lambda p: p[1], points))
        mean_value_vector = sum(map(lambda p: p[1]*p[2], points)) / count

        return tup[0], count, mean_value_vector

    def __calculate_bin_index(self, x):
        index = 0.
        for j in range(x.size):
            delta = (self.bound[j][1] - self.bound[j][0]) / self.K
            i_j = normalize(x[j], self.bound[j][0], self.bound[j][1]) / delta
            if j == 0:
                index += i_j
            else:
                index += (i_j - 1) * pow(self.K, j)

        return int(index)

    def __update_bound(self, data_t):
        for d in range(data_t.shape[0]):
            min= np.min(data_t[d])
            max = np.max(data_t[d])
            if min < self.bound[d][0] or self.bound[d][0] == -1:
                self.bound[d][0] = min
            if max > self.bound[d][1] or self.bound[d][1] == -1:
                self.bound[d][1] = max

def normalize(x, min, max):
    return (x - min) / (max - min)