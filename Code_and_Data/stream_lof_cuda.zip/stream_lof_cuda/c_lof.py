from __future__ import division  # for Python 2

from numba import cuda, float32

import numpy as np
import knn_kernel
import lof_kernel
import math

class C_LOF:

    # block_size: the block size when calculating for the euclidian distance matrix
    # k_size: the size of k neighbourhood
    # fast_euclidean: whether or not to use the fast version of euclidian distance calculation,
    # with shared memory in gpu
    def __init__(self, bin_summary, block_size, k_size, fast_euclidean=True, alpha=1.0, theta=0.5):
        self.bin_summary = bin_summary
        self.block_size = block_size
        self.k_size = k_size
        self.fast_euclidean = fast_euclidean
        self.alpha = alpha
        self.theta = theta
    # find the outliers. -1 means outliers, 1 means inlier
    def fit_predict(self, data):
        data_t = data.T
        c, mu = self.__get_bin_summary_data()
        self._fit(data_t)
        self.lofs = self._score(data_t, c, mu)
        self._update_alpha(self.lofs, c)
        return np.where(np.abs(self.lofs - self.alpha) > self.theta, -np.ones(self.lofs.size), np.ones(self.lofs.size))

    # update the bin summary
    def _fit(self, data_t):
        self.bin_summary.calculate_bin_statistic(data_t)

    # Calcualte the lof scores for each data
    # data: the actual data in current window
    # bin: the virtual data from the bin of previous window
    # c: the count of number of data in each bin
    # threashold of outliers. data index will be printed as outliers if its lof value is larger than threshold
    def _score(self, data, c, mu):
        if mu.size != 0:
            data = np.hstack((data, mu))
        d_data = cuda.to_device(data)
        z = self.__calculate_euclidian(d_data, data)
        k_dists = self.__k_distances(z)

        if mu.size == 0:
            k_nn = self.__k_nearest_neighbourhoods(z)
        else:
            k_nn = self.__k_nearest_neighbourhoods(z[:, 0:-(mu.shape[1])])

        d_knn = cuda.to_device(k_nn)

        lrd = self.__calculate_lrd(d_knn, data, k_dists)
        v_lrd = self.__calculate_virtial_lrd(c)
        total_lrd = np.append(lrd, v_lrd)

        return self.__calculate_lof(d_knn, total_lrd)

    def _update_alpha(self, lofs, count):
        avg = np.average(lofs)
        N = np.sum(count)
        n = lofs.size
        self.alpha = N / (N + n) * self.alpha + n / (N + n) * avg

    def __calculate_euclidian(self, d_x, y):
        threadsperblock = (self.block_size, self.block_size)
        blockdimx = int(math.ceil(d_x.shape[1] / self.block_size))
        blockdimy = int(math.ceil(d_x.shape[1] / self.block_size))
        blockspergrids = (blockdimx, blockdimy)

        d_z = cuda.device_array((d_x.shape[1], d_x.shape[1]))
        if self.fast_euclidean:
            d_y = cuda.to_device(y.T)
            knn_kernel.fast_euclidean_kernel[blockspergrids, threadsperblock](d_x, d_y, d_z)
        else:
            knn_kernel.euclidean_kernel[blockspergrids, threadsperblock](d_x, d_x, d_z)
        z = np.zeros((d_x.shape[1], d_x.shape[1]))
        d_z.copy_to_host(z)
        return z

    def __k_distances(self, z):
        return knn_kernel.k_distance(z, self.k_size)

    def __k_nearest_neighbourhoods(self, z_1):
        return knn_kernel.k_nearest_neighbourhood(z_1, self.k_size)

    def __calculate_lrd(self, k_nn, total, k_dists):
        lrd = np.zeros((k_nn.shape[0]))
        k_dists = np.ascontiguousarray(k_dists)
        lof_kernel.lrd_kernel[k_nn.shape[0], k_nn.shape[1]](k_nn, total, k_dists, lrd)
        return lrd

    def __calculate_virtial_lrd(self, c):
        return np.array([0 if x == 0 else math.log(x) for x in c])

    def __calculate_lof(self, k_nn, total_lrd):
        lofs = np.zeros((k_nn.shape[0]))
        total_lrd = np.ascontiguousarray(total_lrd)
        lof_kernel.lof_kernel[k_nn.shape[0], k_nn.shape[1]](k_nn, total_lrd, lofs)
        return lofs

    def __get_bin_summary_data(self):
        bins = self.bin_summary.bins
        c = np.array([bin[1] for bin in bins], dtype=np.int32)
        mu = np.array([bin[2] for bin in bins], dtype=np.float32)
        return c, mu.T