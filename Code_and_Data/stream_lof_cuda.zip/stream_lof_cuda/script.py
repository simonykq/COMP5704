#!/usr/bin/env python2

import numpy as np
import math
from constants import *
from knn_kernel import fast_euclidean_kernel, euclidean_kernel, fast_euclidean_kernel_2

DATA = np.random.uniform(0, 200, (D, N))
DATA[:, 2] = np.random.uniform(10000,100000, D) # simulate outlier

threadsperblock = (T, T)
blockdimx = int(math.ceil(DATA.shape[1] / T))
blockdimy = int(math.ceil(DATA.shape[1] / T))
blockspergrids = (blockdimx, blockdimy)

Z = np.zeros((N, N))
Z_1 = np.zeros((N, N))
Z_2 = np.zeros((N, N))

if SHARED_MEMORY:
    fast_euclidean_kernel[blockspergrids, threadsperblock](DATA, DATA.T, Z_1)
else:
    euclidean_kernel[blockspergrids, threadsperblock](DATA, DATA, Z)
# fast_euclidean_kernel_2[blockspergrids, threadsperblock](DATA, DATA, Z_2)